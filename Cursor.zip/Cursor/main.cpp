#include <iostream>
#include "menu.h"
#include <conio.h> // Para _getch()

using namespace std;
void menu();

int main() {
	menu();
	
    return 0;
}

